# Visitor-Management-App
App to manage Visitors.

## Get Start

- Execute npm install
- Execute node app.js
- Open http://127.0.0.1:8080/index.html





