exports.sendMail = function () {

  // var nodemailer = require('nodemailer');
  //
  // var transporter = nodemailer.createTransport({
  //   service: 'gmail',
  //   auth: {
  //     user: 'hiteshkrsahu@gmail.com',
  //     pass: 'Rfvtgb1!'
  //   }
  // });
  //
  // var mailOptions = {
  //   from: 'hiteshkrsahu@gmail.com',
  //   to: 'hiteshkumarrsahu1990@gmail.com',
  //   subject: 'Sending Email using Node.js',
  //   text: 'That was easy!'
  // };
  //
  // transporter.sendMail(mailOptions, function(error, info){
  //   if (error) {
  //     console.log(error);
  //   } else {
  //     console.log('Email sent: ' + info.response);
  //   }
  // });
    return Date();
};
