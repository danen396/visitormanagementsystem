var AppConstants = { //not really an enum, just an object that serves a similar purpose

  CONFIG : {
           apiKey: "AIzaSyC9bSGtkJ0CThlvx0BFZMcL6YfWG11H9wk",
           authDomain: "visitor-managment-system-cb454.firebaseapp.com",
           databaseURL: "https://visitor-managment-system-cb454.firebaseio.com",
           projectId: "visitor-managment-system-cb454",
           storageBucket: "visitor-managment-system-cb454.appspot.com",
           messagingSenderId: "36534762743"
         },

  VISTOR_END_POINT : "/Visitors",
}
