module.exports = Object.freeze({
    SERVER_PORT: 8080,
    // Connection URL
     DB_URL : 'mongodb://localhost:27017/VMS',
});
